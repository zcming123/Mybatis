/*
 *    Copyright 2009-2022 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */

import lagou.mapper.IOrderMapper;
import lagou.mapper.IUserMapper;
import lagou.pojo.Order;
import lagou.pojo.User;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

/**
 * <p>Title:  </p>
 * <p>Description: </p>
 *
 * @author Lenovo
 * @date 2022/5/24 0:01
 */
public class MybatisTest {

  /**
   * 传统方法
   */
  public void test1() throws IOException {
    // 1.读取配置文件，读成字节输入流。注意：现在还没解析
    InputStream inputStream = Resources.getResourceAsStream("src/test/resources/sqlMapConfig.xml");
    /**
     * 这个build方法，做两件事：
     * 1、解析配置文件，把解析出来的内容封装成 Configuration对象
     * 2、创建 SqlSessionFactory 的实现类对象 DefaultSqlSessionFactory
     */
    SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
    /**
     * 在生成SqlSession 的过程中， 实例化了Executor
     * 3. 生产了 DefaultSqlSession 实例对象，设置事务不自动提交。完成 Executor 对象的创建
     */
    SqlSession sqlSession = sqlSessionFactory.openSession();
    /**
     * 4.1 根据 statementId ，从 Configuration的 map集合中获取到指定的 MappedStatement 对象
     * 4.2 将查询任务委派给 Executor 执行器
     */
    List<Object> objects = sqlSession.selectList("namespace.id");

  }

  /**1
   * mapper代理方式
   */
  public void test2() throws IOException {
    //前三步都相同
    InputStream inputStream = Resources.getResourceAsStream("src/test/resources/sqlMapConfig.xml");
    SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);
    SqlSession sqlSession = factory.openSession();

    // 使用JDK动态代理，生成 mapper 接口的代理对象。IUserMapper mapper 本质是一个代理对象。
    IUserMapper mapper = sqlSession.getMapper(IUserMapper.class);
    // 代理对象调用接口中的任意方法，执行的都是 动态代理中 invocationHandler 接口的实现类 MapperProxy 的 invoke 方法
    // 在代理对象调用方法时，在执行invoke 方法的过程中，还是执行 SqlSession 的增删改查方法来完成与数据库的交互
    List<Object> list = mapper.findAllUser();
  }


  /**
   * mybatis二级缓存效果测试
   */
  @Test
  public void test3() throws IOException {

    InputStream inputStream = Resources.getResourceAsStream("resources/sqlMapConfig.xml");
    SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);

    SqlSession sqlSession1 = factory.openSession();
    SqlSession sqlSession2 = factory.openSession();

    User user1 = sqlSession1.selectOne("lagou.mapper.IUserMapper.findById", 1);
    System.out.println(user1);

    // 调用 commit 或 close ，才能将查询出来的结果存到二级缓存中
    sqlSession1.commit();

    User user = new User();
    user.setId(1);
    user.setUsername("jack");
    // 增删改会清空二级缓存
    sqlSession1.update("lagou.mapper.IUserMapper.updateById",user);


    User user2 = sqlSession2.selectOne("lagou.mapper.IUserMapper.findById", 1);
    System.out.println(user2);

  }


  /**
   * mybatis嵌套效果测试
   */
  @Test
  public void test4() throws IOException {

    InputStream inputStream = Resources.getResourceAsStream("resources/sqlMapConfig.xml");
    SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(inputStream);

    SqlSession sqlSession = factory.openSession();

    User user = sqlSession.selectOne("lagou.mapper.IUserMapper.findById", 1);

    System.out.println(user.getUsername());
    System.out.println(user.getOrderList());

  }

  /*
        测试一对一查询
     */
  @Test
  public void test5() throws IOException {
    InputStream resourceAsStream = Resources.getResourceAsStream("resources/sqlMapConfig.xml");
    SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
    SqlSession sqlSession = sqlSessionFactory.openSession();
    IOrderMapper mapper = sqlSession.getMapper(IOrderMapper.class);
    List<Order> orderAndUser = mapper.findOrderAndUser();
    for (Order order : orderAndUser) {
      System.out.println(order);
    }
  }

  /*
        测试一对多查询
     */
  @Test
  public void test6() throws IOException {
    InputStream resourceAsStream = Resources.getResourceAsStream("resources/sqlMapConfig.xml");
    SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(resourceAsStream);
    SqlSession sqlSession = sqlSessionFactory.openSession();
    IUserMapper mapper = sqlSession.getMapper(IUserMapper.class);

    List<User> users = mapper.findAll();
    for (User user : users) {
      System.out.println(user.getUsername());
      System.out.println(user.getOrderList());
      System.out.println("============");

    }


  }

}


