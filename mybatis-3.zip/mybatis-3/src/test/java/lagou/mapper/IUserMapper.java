package lagou.mapper;



import lagou.pojo.User;

import java.util.List;

public interface IUserMapper {

    //查询所有用户信息，同时查询出每个用户关联的订单信息
    public List<User>  findAll();

    public List<Object> findAllUser();


    public User findById(Integer id);
}
